use std::{path::PathBuf, time::Duration};

use serde::{Deserialize, Serialize};

use crate::{Error, lenient};

/// Options of a server. Every field has a default, so a config file only needs the fields it
/// changes. Durations are written like `"30s"` or `"5m"`, or as a number of seconds.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct ServerOptions {
    /// Name of the server, used in logs. Default: `"supersocket"`.
    #[serde(deserialize_with = "lenient::string")]
    pub name: String,

    /// Addresses to listen on.
    pub listeners: Vec<ListenOptions>,

    /// Largest package a filter may buffer before it is a protocol error. Default: 1 MiB.
    #[serde(deserialize_with = "lenient::usize")]
    pub max_package_length: usize,

    /// How much to read from a socket at a time while a package is incomplete. Default: 4 KiB.
    /// Idle sessions hold no read buffer.
    #[serde(deserialize_with = "lenient::usize")]
    pub receive_buffer_size: usize,

    /// How long a handler may take for one package. Default: 30 seconds.
    #[serde(with = "lenient::duration")]
    pub package_handling_timeout: Duration,

    /// Whether the packages of a session are handled one at a time or concurrently.
    pub package_handling: PackageHandling,

    /// Close sessions that received nothing for this long. Default: never.
    #[serde(with = "lenient::option_duration")]
    pub idle_session_timeout: Option<Duration>,

    /// How often to look for idle sessions when `idle_session_timeout` is set. Default: 2 minutes.
    #[serde(with = "lenient::duration")]
    pub clear_idle_session_interval: Duration,

    /// Close a session whose peer does not accept sent data for this long. Default: never.
    #[serde(with = "lenient::option_duration")]
    pub send_timeout: Option<Duration>,

    /// Once this much data is waiting to be sent on a session, [`send`](crate::Session::send)
    /// waits for it to drain. A single send is accepted whenever nothing is waiting, so `0` sends
    /// one piece at a time. Default: 64 KiB.
    #[serde(deserialize_with = "lenient::usize")]
    pub send_buffer_limit: usize,

    /// How long a closing session may take to send data that is still queued. Default: 5 seconds.
    #[serde(with = "lenient::duration")]
    pub close_timeout: Duration,

    /// How long a connection may take to become connected once admitted for processing: reading
    /// the PROXY protocol header, the TLS handshake, the stream layers and the protocol handshake
    /// of a server that [requires one](crate::ServerBuilder::require_handshake), all together.
    /// Waiting for a connection slot does not count. A connection that takes longer is dropped.
    /// Default: 10 seconds.
    #[serde(with = "lenient::duration")]
    pub handshake_timeout: Duration,

    /// How many connections the server serves at a time, including handshakes. At the limit,
    /// each listener holds at most one accepted socket waiting for a session to end; further
    /// connections wait in the listen backlog. Idle listeners do not consume capacity.
    /// Default: no limit.
    #[serde(deserialize_with = "lenient::option_usize")]
    pub max_connections: Option<usize>,
}

impl Default for ServerOptions {
    fn default() -> Self {
        Self {
            name: "supersocket".into(),
            listeners: Vec::new(),
            max_package_length: 1024 * 1024,
            receive_buffer_size: 4 * 1024,
            package_handling_timeout: Duration::from_secs(30),
            package_handling: PackageHandling::Serial,
            idle_session_timeout: None,
            clear_idle_session_interval: Duration::from_secs(120),
            send_timeout: None,
            send_buffer_limit: 64 * 1024,
            close_timeout: Duration::from_secs(5),
            handshake_timeout: Duration::from_secs(10),
            max_connections: None,
        }
    }
}

impl ServerOptions {
    /// Rejects values that cannot work, such as zero sizes and zero timeouts.
    /// [`ServerBuilder::build`](crate::ServerBuilder::build) calls this.
    pub fn validate(&self) -> Result<(), Error> {
        let invalid = |message: String| Err(Error::InvalidOptions(message));
        if self.max_package_length == 0 {
            return invalid("max_package_length must be greater than zero".into());
        }
        if self.receive_buffer_size == 0 {
            return invalid("receive_buffer_size must be greater than zero".into());
        }
        if self.package_handling_timeout.is_zero() {
            return invalid("package_handling_timeout must be greater than zero".into());
        }
        if let PackageHandling::Concurrent { max_in_flight: 0 } = self.package_handling {
            return invalid("max_in_flight must be greater than zero".into());
        }
        if let Some(timeout) = self.idle_session_timeout {
            if timeout.is_zero() {
                return invalid("idle_session_timeout must be greater than zero".into());
            }
            if self.clear_idle_session_interval.is_zero() {
                return invalid("clear_idle_session_interval must be greater than zero".into());
            }
        }
        if self.send_timeout.is_some_and(|timeout| timeout.is_zero()) {
            return invalid("send_timeout must be greater than zero".into());
        }
        if self.handshake_timeout.is_zero() {
            return invalid("handshake_timeout must be greater than zero".into());
        }
        if self.max_connections == Some(0) {
            return invalid("max_connections must be greater than zero".into());
        }
        for listener in &self.listeners {
            let zero = |field: &str| {
                invalid(format!(
                    "listener {}: {field} must be greater than zero",
                    listener.address
                ))
            };
            if listener.backlog == 0 {
                return zero("backlog");
            }
            if listener.keepalive.is_some_and(|time| time.is_zero()) {
                return zero("keepalive");
            }
            if listener.socket_receive_buffer_size == Some(0) {
                return zero("socket_receive_buffer_size");
            }
            if listener.socket_send_buffer_size == Some(0) {
                return zero("socket_send_buffer_size");
            }
            #[cfg(feature = "tls")]
            if let Some(tls) = &listener.tls {
                if tls.config.is_some()
                    && (tls.client_ca.is_some()
                        || tls.client_auth_optional
                        || !tls.cert.as_os_str().is_empty()
                        || !tls.key.as_os_str().is_empty())
                {
                    return invalid(format!(
                        "listener {}: a TLS config replaces cert, key and the client certificate \
                         settings; set them in the rustls configuration instead",
                        listener.address
                    ));
                }
            }
        }
        Ok(())
    }
}

/// How the packages of one session are handled.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
#[non_exhaustive]
pub enum PackageHandling {
    /// One package at a time, in the order received. Reading pauses while a package is handled.
    #[default]
    Serial,
    /// Packages are handled concurrently on the runtime's worker threads, in no particular order.
    /// Reading pauses while `max_in_flight` packages of the session are being handled.
    Concurrent {
        /// How many packages of one session may be handled at the same time.
        #[serde(deserialize_with = "lenient::usize")]
        max_in_flight: usize,
    },
}

/// A listening address and the settings of the connections accepted on it.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ListenOptions {
    /// Socket address to bind, such as `"0.0.0.0:4040"` or `"[::]:4040"`. Port 0 picks a free port.
    #[serde(deserialize_with = "lenient::string")]
    pub address: String,

    /// Length of the queue of connections waiting to be accepted. Default: 1024.
    #[serde(default = "default_backlog", deserialize_with = "lenient::u32")]
    pub backlog: u32,

    /// Whether to disable Nagle's algorithm on accepted connections. Default: `true`.
    #[serde(default = "default_no_delay", deserialize_with = "lenient::bool")]
    pub no_delay: bool,

    /// Send TCP keepalive probes once a connection has been idle this long, so that connections
    /// whose peer vanished are noticed. Default: off.
    #[serde(default, with = "lenient::option_duration")]
    pub keepalive: Option<Duration>,

    /// Size of the kernel's receive buffer of each connection, `SO_RCVBUF`. Unrelated to
    /// [`ServerOptions::receive_buffer_size`], which is how much the server reads at a time.
    /// Default: the operating system's.
    #[serde(default, deserialize_with = "lenient::option_u32")]
    pub socket_receive_buffer_size: Option<u32>,

    /// Size of the kernel's send buffer of each connection, `SO_SNDBUF`. Default: the operating
    /// system's.
    #[serde(default, deserialize_with = "lenient::option_u32")]
    pub socket_send_buffer_size: Option<u32>,

    /// Whether connections start with a PROXY protocol header, version 1 or 2, as they do behind
    /// HAProxy, nginx or an AWS Network Load Balancer configured to send one. The header tells
    /// the client's address, which [`Session::remote_addr`](crate::Session::remote_addr) then
    /// reports. Connections without a valid header are closed, so enable it only on listeners
    /// that are reachable through the proxy alone. Default: `false`.
    #[serde(default, deserialize_with = "lenient::bool")]
    pub proxy_protocol: bool,

    /// Accept TLS connections with this certificate. Requires the `tls` feature.
    #[serde(default)]
    pub tls: Option<TlsOptions>,
}

impl ListenOptions {
    /// Plain TCP on `address` with default settings.
    pub fn new(address: impl Into<String>) -> Self {
        Self {
            address: address.into(),
            backlog: default_backlog(),
            no_delay: default_no_delay(),
            keepalive: None,
            socket_receive_buffer_size: None,
            socket_send_buffer_size: None,
            proxy_protocol: false,
            tls: None,
        }
    }
}

fn default_backlog() -> u32 {
    1024
}

fn default_no_delay() -> bool {
    true
}

/// TLS settings of a listener. The certificate chain, the private key and the client certificate
/// authorities are PEM files. The handshake is limited by
/// [`ServerOptions::handshake_timeout`].
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TlsOptions {
    /// PEM file with the certificate chain, leaf certificate first.
    #[serde(deserialize_with = "lenient::path")]
    pub cert: PathBuf,

    /// PEM file with the private key.
    #[serde(deserialize_with = "lenient::path")]
    pub key: PathBuf,

    /// PEM file with the certificate authorities that client certificates must chain to.
    /// Setting it makes the server ask every client for a certificate and refuse clients
    /// without a valid one; see [`Session::tls_info`](crate::Session::tls_info) for the
    /// certificate a client sent. Default: none.
    #[serde(default, deserialize_with = "lenient::option_path")]
    pub client_ca: Option<PathBuf>,

    /// With `client_ca`, still accept clients that send no certificate. Those that send one must
    /// send a valid one. Default: `false`.
    #[serde(default, deserialize_with = "lenient::bool")]
    pub client_auth_optional: bool,

    /// A complete rustls configuration to use instead of one built from the files above, for
    /// what they cannot express, such as ALPN, a certificate per server name or a custom client
    /// certificate verifier. Not read from config files.
    #[cfg(feature = "tls")]
    #[serde(skip)]
    pub config: Option<std::sync::Arc<tokio_rustls::rustls::ServerConfig>>,
}

impl TlsOptions {
    /// TLS with the certificate chain and private key in the given PEM files.
    pub fn new(cert: impl Into<PathBuf>, key: impl Into<PathBuf>) -> Self {
        Self {
            cert: cert.into(),
            key: key.into(),
            client_ca: None,
            client_auth_optional: false,
            #[cfg(feature = "tls")]
            config: None,
        }
    }

    /// TLS with a complete rustls configuration; see [`config`](Self::config).
    #[cfg(feature = "tls")]
    pub fn with_config(config: std::sync::Arc<tokio_rustls::rustls::ServerConfig>) -> Self {
        Self {
            config: Some(config),
            ..Self::new(PathBuf::new(), PathBuf::new())
        }
    }
}

impl PartialEq for TlsOptions {
    fn eq(&self, other: &Self) -> bool {
        #[cfg(feature = "tls")]
        let same_config = match (&self.config, &other.config) {
            (Some(ours), Some(theirs)) => std::sync::Arc::ptr_eq(ours, theirs),
            (ours, theirs) => ours.is_none() && theirs.is_none(),
        };
        #[cfg(not(feature = "tls"))]
        let same_config = true;
        same_config
            && self.cert == other.cert
            && self.key == other.key
            && self.client_ca == other.client_ca
            && self.client_auth_optional == other.client_auth_optional
    }
}
